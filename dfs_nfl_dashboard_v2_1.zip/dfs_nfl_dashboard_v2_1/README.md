# NFL DFS Dashboard V2.1

Mobile/cloud edition of the DraftKings-style 2026 Week 1 NFL DFS dashboard.

## V2.1 changes
- Mobile-first layout for iPhone Safari
- Sidebar starts collapsed to maximize phone screen space
- Single dashboard-view selector instead of a wide tab bar
- Touch-sized buttons and form controls
- Responsive 3-column KPI rows
- Streamlit Community Cloud configuration included
- Pinned Streamlit dependency for more predictable cloud deployments
- Deployment guide for GitHub + Streamlit Community Cloud
- Portfolio exposure fix: 0% can truly exclude a player from generated portfolios; portfolio locks are treated as 100% exposure

## Run locally

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Deploy for iPhone
Read `DEPLOY_IPHONE.md`.

## Data note
`sample_week1_main_slate.csv` contains synthetic placeholder players for testing only. It is not a live DraftKings feed.
